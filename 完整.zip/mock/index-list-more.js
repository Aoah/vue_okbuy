module.exports = {
    "data": [{
        "id": 1,
        "img": "./images/img1.png",
        "title": "more西甲-巴萨3-4客负 皇马1-1丢榜首"
    }, {
        "id": 2,
        "img": "./images/img2.jpg",
        "title": "more英超-曼联憾平 曼城0-2热刺 瓜帅首败"
    }]
}
