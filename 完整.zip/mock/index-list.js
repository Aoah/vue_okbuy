module.exports = {
    "data": [{
        "id": 1,
        "img": "./images/img1.png",
        "title": "西甲-巴萨3-4客负 皇马1-1丢榜首"
    }, {
        "id": 2,
        "img": "./images/img2.jpg",
        "title": "英超-曼联憾平 曼城0-2热刺 瓜帅首败"
    }, {
        "id": 3,
        "img": "./images/img3.jpg",
        "title": "意甲-AC米兰4-3 国米1-2罗马"
    }, {
        "id": 4,
        "img": "./images/img4.jpg",
        "title": "德甲-拜仁1-1终结连胜 药厂擒多特"
    }, {
        "id": 5,
        "img": "./images/img1.png",
        "title": "西甲-巴萨3-4客负 皇马1-1丢榜首"
    }, {
        "id": 6,
        "img": "./images/img2.jpg",
        "title": "英超-曼联憾平 曼城0-2热刺 瓜帅首败"
    }, {
        "id": 7,
        "img": "./images/img3.jpg",
        "title": "意甲-AC米兰4-3 国米1-2罗马"
    }, {
        "id": 8,
        "img": "./images/img4.jpg",
        "title": "德甲-拜仁1-1终结连胜 药厂擒多特"
    }]
}
