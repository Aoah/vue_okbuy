module.exports = {
    "data": [{
        "id": 1,
        "width": 522,
        "height": 783,
        "img": "./images/img1.png",
        "title": "西甲-巴萨3-4客负 皇马1-1丢榜首"
    }, {
        "id": 2,
        "width": 500,
        "height": 700,
        "img": "./images/img2.jpg",
        "title": "英超-曼联憾平 曼城0-2热刺 瓜帅首败"
    }, {
        "id": 3,
        "width": 535,
        "height": 578,
        "img": "./images/img3.jpg",
        "title": "意甲-AC米兰4-3 国米1-2罗马"
    }, {
        "id": 4,
        "width": 510,
        "height": 200,
        "img": "./images/img4.jpg",
        "title": "德甲-拜仁1-1终结连胜 药厂擒多特"
    }, {
        "id": 5,
        "width": 560,
        "height": 414,
        "img": "./images/img1.png",
        "title": "西甲-巴萨3-4客负 皇马1-1丢榜首"
    }, {
        "id": 6,
        "width": 580,
        "height": 312,
        "img": "./images/img2.jpg",
        "title": "英超-曼联憾平 曼城0-2热刺 瓜帅首败"
    }, {
        "id": 7,
        "width": 555,
        "height": 777,
        "img": "./images/img3.jpg",
        "title": "意甲-AC米兰4-3 国米1-2罗马"
    }, {
        "id": 8,
        "width": 460,
        "height": 300,
        "img": "./images/img4.jpg",
        "title": "德甲-拜仁1-1终结连胜 药厂擒多特"
    }]
}
